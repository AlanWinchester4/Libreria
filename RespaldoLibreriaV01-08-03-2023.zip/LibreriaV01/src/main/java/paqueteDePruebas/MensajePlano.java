package paqueteDePruebas;

public class MensajePlano implements Mensaje
{

	@Override
	public void hola() 
	{
		System.out.println("Hola");
	}

}
