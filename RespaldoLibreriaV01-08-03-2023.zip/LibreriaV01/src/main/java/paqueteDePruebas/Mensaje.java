package paqueteDePruebas;

public interface Mensaje 
{
	public void hola();
}
